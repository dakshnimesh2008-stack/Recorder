# Recorder

Native Kotlin Android project.

## Features
- Minimal dark UI, with 720p / 540p / 480p and 30 / 24 / 15 FPS settings.
- Floating timer ball with Pause, Resume and Stop.
- Foreground notification.
- Quick Settings tile named Recorder; add it from the system tile editor.
- Silent recording, microphone audio in the MP4, or device playback capture on Android 10+.

## Device audio limitation
This build captures eligible playback into a separate WAV file under `Music/Recorder`. It is **not embedded in the MP4**. Android apps/games can block playback capture, and a full synchronized video+internal-audio MP4 muxing pipeline is not included. Microphone audio is embedded in the MP4 when selected.

## Build
Upload the contents of this ZIP to the root of your GitHub repository (do not upload only the ZIP file). Commit the files, then run the included GitHub Actions workflow and download the APK artifact.

## Important
- The app cannot guarantee continued recording after Android Force stop, reboot, permission revocation, or system failure.
- Overlay visibility in recorded footage varies by device and needs on-device testing.
- This project has not been compiled or tested on the target phone in this environment.
