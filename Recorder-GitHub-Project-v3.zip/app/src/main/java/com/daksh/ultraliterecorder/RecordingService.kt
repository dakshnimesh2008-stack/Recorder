package com.daksh.ultraliterecorder

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.content.ContentValues
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Records screen video with MediaRecorder. Optional Android 10+ playback capture
 * is captured by AudioRecord and stored as a WAV sidecar beside the MP4.
 * Android's public MediaRecorder API cannot accept an AudioRecord playback-capture
 * stream as its audio source; muxing it into the MP4 needs a separate codec pipeline.
 */
class RecordingService : Service() {
    companion object {
        const val ACTION_START = "com.daksh.ultraliterecorder.START"
        const val ACTION_PAUSE = "com.daksh.ultraliterecorder.PAUSE"
        const val ACTION_RESUME = "com.daksh.ultraliterecorder.RESUME"
        const val ACTION_STOP = "com.daksh.ultraliterecorder.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "recorder_active"
        private const val NOTIFICATION_ID = 45
    }

    private var recorder: MediaRecorder? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var controls: LinearLayout? = null
    private var outputUri: android.net.Uri? = null
    private var outputPfd: ParcelFileDescriptor? = null
    private var outputName = ""
    private var audioThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private var audioRunning = AtomicBoolean(false)
    private var audioRaw: File? = null
    private var audioMode = 0
    private var resolutionChoice = 0
    private var fps = 30
    private var recording = false
    private var paused = false
    private var startAt = 0L
    private var pausedTotal = 0L
    private var pauseAt = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (recording) {
                updateBubble()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val data = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA) as? Intent
                }
                if (data == null) { stopSelf(); return START_NOT_STICKY }
                audioMode = intent.getIntExtra("audio", 0)
                resolutionChoice = intent.getIntExtra("resolution", 0)
                fps = when (intent.getIntExtra("fps", 0)) { 1 -> 24; 2 -> 15; else -> 30 }
                startForegroundCompat()
                startCapture(intent.getIntExtra(EXTRA_RESULT_CODE, 0), data)
            }
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_STOP -> stopRecording()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Screen recording", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("Recorder · Recording")
            .setContentText("Tap to return to recording controls")
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOngoing(true).setContentIntent(open).build()
        else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle("Recorder · Recording").setContentText("Tap to return to controls")
                .setOngoing(true).setContentIntent(open).build()
        }
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, n)
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        try {
            val dm = resources.displayMetrics
            val maxEdge = when (resolutionChoice) { 1 -> 540f; 2 -> 480f; else -> 720f }
            val scale = minOf(1f, maxEdge / maxOf(dm.widthPixels, dm.heightPixels).toFloat())
            val width = maxOf(2, ((dm.widthPixels * scale).toInt() / 2) * 2)
            val height = maxOf(2, ((dm.heightPixels * scale).toInt() / 2) * 2)
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            outputName = "Recorder_$stamp.mp4"
            createOutput(outputName)

            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else {
                @Suppress("DEPRECATION") MediaRecorder()
            }
            recorder!!.apply {
                if (audioMode == 2) setAudioSource(MediaRecorder.AudioSource.MIC)
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                if (audioMode == 2) setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setVideoSize(width, height)
                setVideoFrameRate(fps)
                setVideoEncodingBitRate(when (resolutionChoice) { 1 -> 1800000; 2 -> 1200000; else -> 3000000 })
                setOutputFile(outputPfd!!.fileDescriptor)
                prepare()
            }

            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopRecording() }
            }, handler)
            virtualDisplay = projection!!.createVirtualDisplay("RecorderDisplay", width, height, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder!!.surface, null, handler)
            recorder!!.start()
            recording = true
            paused = false
            startAt = SystemClock.elapsedRealtime()
            pausedTotal = 0
            showBubble()
            handler.post(tick)
            if (audioMode == 1) startPlaybackCapture()
            Toast.makeText(this, "Recording started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message ?: "recording error"}", Toast.LENGTH_LONG).show()
            cleanup(false)
            stopSelf()
        }
    }

    private fun createOutput(name: String) {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Recorder")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            outputPfd = outputUri?.let { contentResolver.openFileDescriptor(it, "w") }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Recorder")
            dir.mkdirs()
            val file = File(dir, name)
            outputPfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_WRITE_ONLY or ParcelFileDescriptor.MODE_TRUNCATE)
        }
        if (outputPfd == null) throw IOException("Could not create output video")
    }

    private fun startPlaybackCapture() {
        if (Build.VERSION.SDK_INT < 29) {
            Toast.makeText(this, "Device audio needs Android 10+", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val sampleRate = 44100
            val channelConfig = android.media.AudioFormat.CHANNEL_IN_STEREO
            val format = android.media.AudioFormat.Builder()
                .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate).setChannelMask(channelConfig).build()
            val minBuffer = AudioRecord.getMinBufferSize(sampleRate, channelConfig, android.media.AudioFormat.ENCODING_PCM_16BIT)
            audioRecord = AudioRecord.Builder().setAudioFormat(format)
                .setBufferSizeInBytes(maxOf(minBuffer * 2, 16384))
                .setAudioPlaybackCaptureConfig(config).build()
            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Device audio capture not initialized")
            val rawName = outputName.removeSuffix(".mp4") + "_device_audio.wav"
            audioRaw = File(cacheDir, rawName)
            audioRunning.set(true)
            audioThread = Thread {
                val pcm = FileOutputStream(audioRaw!!)
                val buffer = ByteArray(8192)
                var bytesWritten = 0L
                try {
                    audioRecord?.startRecording()
                    while (audioRunning.get()) {
                        val n = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                        if (n > 0) { pcm.write(buffer, 0, n); bytesWritten += n }
                    }
                } catch (_: Exception) {
                } finally {
                    try { pcm.close() } catch (_: Exception) {}
                    try { audioRecord?.stop() } catch (_: Exception) {}
                    if (audioRaw?.exists() == true) writeWavHeader(audioRaw!!, bytesWritten, sampleRate, 2)
                }
            }.apply { name = "RecorderPlaybackCapture"; start() }
            Toast.makeText(this, "Device audio capture started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Device audio unavailable: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun publishDeviceAudio() {
        val src = audioRaw ?: return
        if (!src.exists() || src.length() < 44) return
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, src.name)
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Recorder")
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return
                contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
                src.delete()
            }
        } catch (_: Exception) {}
    }

    private fun writeWavHeader(file: File, pcmLength: Long, sampleRate: Int, channels: Int) {
        val data = file.readBytes()
        val tmp = File(file.parentFile, file.name + ".tmp")
        DataOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { out ->
            out.writeBytes("RIFF"); writeIntLE(out, (36 + pcmLength).toInt())
            out.writeBytes("WAVEfmt "); writeIntLE(out, 16); writeShortLE(out, 1)
            writeShortLE(out, channels); writeIntLE(out, sampleRate)
            writeIntLE(out, sampleRate * channels * 2); writeShortLE(out, channels * 2); writeShortLE(out, 16)
            out.writeBytes("data"); writeIntLE(out, pcmLength.toInt()); out.write(data)
        }
        file.delete(); tmp.renameTo(file)
    }
    private fun writeIntLE(out: DataOutputStream, n: Int) { out.writeByte(n); out.writeByte(n shr 8); out.writeByte(n shr 16); out.writeByte(n shr 24) }
    private fun writeShortLE(out: DataOutputStream, n: Int) { out.writeByte(n); out.writeByte(n shr 8) }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "● 00:00"; textSize = 12f; setTextColor(-1)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xEE172235.toInt()); setStroke(dp(2), 0xFF65E0AC.toInt())
            }
            gravity = Gravity.CENTER; elevation = dp(6).toFloat()
            setOnClickListener { toggleControls() }
            setOnTouchListener(object : View.OnTouchListener {
                var x0=0; var y0=0; var sx=0; var sy=0; var moved=false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    when(e.action) {
                        MotionEvent.ACTION_DOWN -> { x0=e.rawX.toInt(); y0=e.rawY.toInt(); sx=lp.x; sy=lp.y; moved=false; return true }
                        MotionEvent.ACTION_MOVE -> {
                            val dx=e.rawX.toInt()-x0; val dy=e.rawY.toInt()-y0
                            if (kotlin.math.abs(dx)>dp(5)||kotlin.math.abs(dy)>dp(5)) moved=true
                            lp.x=sx-dx; lp.y=sy+dy
                            try { wm?.updateViewLayout(v,lp) } catch (_:Exception) {}
                            return true
                        }
                        MotionEvent.ACTION_UP -> { if(!moved) v.performClick(); return true }
                    }; return false
                }
            })
        }
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp=WindowManager.LayoutParams(-2,-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT)
        lp.gravity=Gravity.TOP or Gravity.END; lp.x=dp(14); lp.y=dp(130)
        wm?.addView(bubble,lp)
    }

    private fun toggleControls() {
        if (controls != null) { removeControls(); return }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(8),dp(8),dp(8),dp(8)); background=android.graphics.drawable.GradientDrawable().apply { setColor(0xF0222C3B.toInt()); cornerRadius=dp(16).toFloat() } }
        box.addView(Button(this).apply { text=if(paused) "Resume" else "Pause"; isAllCaps=false; setOnClickListener { if(paused){resumeRecording();text="Pause"}else{pauseRecording();text="Resume"} } },LinearLayout.LayoutParams(dp(112),dp(46)))
        box.addView(Button(this).apply { text="Stop"; isAllCaps=false; setOnClickListener { stopRecording() } },LinearLayout.LayoutParams(dp(112),dp(46)).apply { topMargin=dp(4) })
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp=WindowManager.LayoutParams(-2,-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT)
        lp.gravity=Gravity.TOP or Gravity.END; lp.x=dp(14); lp.y=dp(190)
        controls=box; wm?.addView(box,lp)
    }

    private fun pauseRecording() {
        if(!recording||paused)return
        try { if(Build.VERSION.SDK_INT>=24){recorder?.pause();paused=true;pauseAt=SystemClock.elapsedRealtime();updateBubble()} }
        catch(e:Exception){Toast.makeText(this,"Pause failed",Toast.LENGTH_SHORT).show()}
    }
    private fun resumeRecording() {
        if(!recording||!paused)return
        try { recorder?.resume();pausedTotal+=SystemClock.elapsedRealtime()-pauseAt;paused=false;updateBubble() }
        catch(e:Exception){Toast.makeText(this,"Resume failed",Toast.LENGTH_SHORT).show()}
    }
    private fun updateBubble() {
        val now=if(paused)pauseAt else SystemClock.elapsedRealtime()
        val sec=((now-startAt-pausedTotal).coerceAtLeast(0)/1000).toInt()
        bubble?.text=(if(paused)"Ⅱ " else "● ")+String.format(Locale.US,"%02d:%02d",sec/60,sec%60)
    }
    private fun stopRecording() {
        if(!recording && recorder==null){stopSelf();return}
        recording=false; handler.removeCallbacks(tick)
        audioRunning.set(false)
        try { audioThread?.join(1500) } catch (_:Exception) {}
        try { recorder?.stop() } catch (_:Exception) {}
        cleanup(true)
        publishDeviceAudio()
        Toast.makeText(this,"Video saved in Movies/Recorder",Toast.LENGTH_LONG).show()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    private fun cleanup(finalize:Boolean) {
        audioRunning.set(false)
        try{audioRecord?.release()}catch(_:Exception){}; audioRecord=null
        try{virtualDisplay?.release()}catch(_:Exception){};virtualDisplay=null
        try{recorder?.reset()}catch(_:Exception){};try{recorder?.release()}catch(_:Exception){};recorder=null
        try{projection?.stop()}catch(_:Exception){};projection=null
        try{outputPfd?.close()}catch(_:Exception){};outputPfd=null
        if(Build.VERSION.SDK_INT>=29&&outputUri!=null){
            try{if(finalize){val v=ContentValues().apply{put(MediaStore.Video.Media.IS_PENDING,0)};contentResolver.update(outputUri!!,v,null,null)}else contentResolver.delete(outputUri!!,null,null)}catch(_:Exception){}
        }
        outputUri=null
        try{bubble?.let{wm?.removeView(it)}}catch(_:Exception){};bubble=null;removeControls()
        // Keep WAV in app cache only; the video is the user-facing output.
    }
    private fun removeControls(){try{controls?.let{wm?.removeView(it)}}catch(_:Exception){};controls=null}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onDestroy(){handler.removeCallbacks(tick);if(recording||recorder!=null)cleanup(false);super.onDestroy()}
}
