package com.daksh.ultraliterecorder

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var resolution: Spinner
    private lateinit var fps: Spinner
    private lateinit var audio: Spinner
    private lateinit var projectionManager: MediaProjectionManager
    private val captureRequest = 5107
    private val prefs by lazy { getSharedPreferences("recorder_settings", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        buildUi()
    }

    private fun buildUi() {
        val bg = 0xFF0C1018.toInt()
        val panel = 0xFF171F2D.toInt()
        val accent = 0xFF65E0AC.toInt()
        val white = 0xFFF2F5FA.toInt()
        val muted = 0xFF9AA8BB.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(24))
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "●  ULTRALITE"
            textSize = 12f
            letterSpacing = .15f
            setTextColor(accent)
        })
        root.addView(TextView(this).apply {
            text = "Screen Recorder"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            setPadding(0, dp(8), 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "Lightweight controls for gameplay"
            textSize = 14f
            setTextColor(muted)
        })

        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(panel, dp(18))
        }
        root.addView(statusCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })
        statusCard.addView(TextView(this).apply {
            text = "STATUS"
            textSize = 11f
            letterSpacing = .1f
            setTextColor(muted)
        })
        status = TextView(this).apply {
            text = "Ready to record"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            setPadding(0, dp(6), 0, dp(2))
        }
        statusCard.addView(status)
        statusCard.addView(TextView(this).apply {
            text = "Floating timer appears after screen-capture permission."
            textSize = 12f
            setTextColor(muted)
        })

        val settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(8))
            background = rounded(panel, dp(18))
        }
        root.addView(settings, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        settings.addView(TextView(this).apply {
            text = "RECORDING SETTINGS"
            textSize = 11f
            letterSpacing = .1f
            setTextColor(accent)
        })
        resolution = spinner(listOf("720p (recommended)", "540p (lighter)", "480p (lowest)"), prefs.getInt("resolution", 0))
        fps = spinner(listOf("30 FPS", "24 FPS", "15 FPS (lighter)"), prefs.getInt("fps", 0))
        audio = spinner(listOf("Silent", "Device audio (Android 10+)", "Microphone audio"), prefs.getInt("audio", 0))
        addSetting(settings, "Resolution", resolution)
        addSetting(settings, "Frame rate", fps)
        addSetting(settings, "Audio source", audio)

        startButton = Button(this).apply {
            text = "START RECORDING"
            isAllCaps = false
            textSize = 14f
            setTextColor(0xFF06130D.toInt())
            backgroundTintList = ColorStateList.valueOf(accent)
            setOnClickListener { saveSettingsAndStart() }
        }
        root.addView(startButton, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(18) })

        val overlayButton = Button(this).apply {
            text = "Enable floating ball"
            isAllCaps = false
            setTextColor(white)
            backgroundTintList = ColorStateList.valueOf(0xFF2B374A.toInt())
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), 5108)
                } else Toast.makeText(this@MainActivity, "Floating ball permission is enabled", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(overlayButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })

        root.addView(TextView(this).apply {
            text = "Device audio capture is Android 10+ only and some games block it. In this build, captured device audio is a separate WAV file; it is not muxed into the MP4. Microphone audio is recorded into the MP4."
            textSize = 12f
            setTextColor(0xFFFFC98B.toInt())
            setPadding(0, dp(14), 0, 0)
        })
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); addView(root) }
        setContentView(scroll)
    }

    private fun saveSettingsAndStart() {
        prefs.edit()
            .putInt("resolution", resolution.selectedItemPosition)
            .putInt("fps", fps.selectedItemPosition)
            .putInt("audio", audio.selectedItemPosition)
            .apply()

        if (!Settings.canDrawOverlays(this)) {
            status.text = "Enable floating ball permission first"
            @Suppress("DEPRECATION")
            startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), 5108)
            return
        }
        if (audio.selectedItemPosition == 2 && Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5109)
            return
        }
        startButton.isEnabled = false
        startButton.text = "WAITING FOR PERMISSION…"
        startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated by Android API; retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, RecordingService::class.java).apply {
                    action = RecordingService.ACTION_START
                    putExtra(RecordingService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(RecordingService.EXTRA_DATA, data)
                    putExtra("resolution", prefs.getInt("resolution", 0))
                    putExtra("fps", prefs.getInt("fps", 0))
                    putExtra("audio", prefs.getInt("audio", 0))
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                status.text = "Starting recording…"
            } else status.text = "Screen capture cancelled"
            startButton.isEnabled = true
            startButton.text = "START RECORDING"
        }
    }

    private fun spinner(items: List<String>, selected: Int): Spinner {
        return Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(selected.coerceIn(items.indices))
        }
    }

    private fun addSetting(parent: LinearLayout, label: String, control: Spinner) {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(0xFFC7D0DE.toInt())
            setPadding(0, dp(12), 0, dp(2))
        })
        parent.addView(control, LinearLayout.LayoutParams(-1, dp(44)))
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
