# UltraLite Recorder Pro

Native Android screen-recorder project with a clean UI, movable floating timer ball, and Pause/Resume/Stop controls.

## Build with GitHub Actions
Upload the *contents* of this ZIP to the repository root (do not upload this ZIP as the only project file). Commit, then open Actions and run **Build UltraLite Recorder Pro**. Download `UltraLiteRecorderPro-debug-apk` from the successful run's Artifacts section.

## Use
1. Install APK.
2. Open app and enable Display over other apps for the floating ball.
3. Tap Start Recording and approve Android's screen capture prompt.
4. Tap the floating timer ball for Pause/Resume and Stop.
5. Video is saved to Movies/UltraLiteRecorder.

## Limitations
This starter build records video only (no internal game audio or microphone). Android's capture consent cannot be bypassed. Force-stop, reboot, revoked capture permission, or OS/vendor termination can stop recording; no app can guarantee survival through these cases. Test on your device before long recordings.
