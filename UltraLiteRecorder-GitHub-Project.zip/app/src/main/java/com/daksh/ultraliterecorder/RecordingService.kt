package com.daksh.ultraliterecorder

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.content.ContentValues
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class RecordingService : Service() {
    companion object {
        const val ACTION_START = "com.daksh.ultraliterecorder.START"
        const val ACTION_PAUSE = "com.daksh.ultraliterecorder.PAUSE"
        const val ACTION_RESUME = "com.daksh.ultraliterecorder.RESUME"
        const val ACTION_STOP = "com.daksh.ultraliterecorder.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "ulr_recording"
        private const val NOTIFY_ID = 45
    }
    private var recorder: MediaRecorder? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var wm: WindowManager? = null
    private var ball: TextView? = null
    private var menu: LinearLayout? = null
    private var recording = false
    private var paused = false
    private var startedAt = 0L
    private var pausedTotal = 0L
    private var pauseAt = 0L
    private var pfd: ParcelFileDescriptor? = null
    private var uri: android.net.Uri? = null
    private var oldFile: File? = null
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable { override fun run() { if (recording) { updateTimer(); handler.postDelayed(this, 1000) } } }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") (intent.getParcelableExtra(EXTRA_DATA) as? Intent)
                if (data == null) { stopSelf(); return START_NOT_STICKY }
                showNotification()
                startCapture(code, data)
            }
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_STOP -> stopRecording()
        }
        return START_NOT_STICKY
    }

    private fun showNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Screen recording", NotificationManager.IMPORTANCE_LOW))
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        val notification = builder.setContentTitle("UltraLite Recorder is recording")
            .setContentText("Use the floating timer ball to pause or stop")
            .setSmallIcon(android.R.drawable.presence_video_online).setContentIntent(pending).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFY_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(NOTIFY_ID, notification)
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        try {
            val dm = resources.displayMetrics
            val scale = minOf(1f, 720f / maxOf(dm.widthPixels, dm.heightPixels).toFloat())
            val w = maxOf(2, ((dm.widthPixels * scale).toInt() / 2) * 2)
            val h = maxOf(2, ((dm.heightPixels * scale).toInt() / 2) * 2)
            makeOutput()
            val fd = pfd?.fileDescriptor ?: error("Could not create video file")
            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            recorder!!.apply {
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setVideoSize(w, h)
                setVideoFrameRate(30)
                setVideoEncodingBitRate(2_500_000)
                setOutputFile(fd)
                prepare()
            }
            val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = pm.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { if (recording) stopRecording() } }, handler)
            display = projection?.createVirtualDisplay("UltraLiteRecorder", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder!!.surface, null, handler)
            recorder!!.start()
            recording = true; paused = false; startedAt = SystemClock.elapsedRealtime(); pausedTotal = 0
            createBall(); handler.post(ticker)
            Toast.makeText(this, "Recording started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start recording: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
            releaseAll(false); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
        }
    }

    private fun makeOutput() {
        val name = "ULR_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, name); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/UltraLiteRecorder"); put(MediaStore.Video.Media.IS_PENDING, 1) }
            uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: error("MediaStore insert failed")
            pfd = contentResolver.openFileDescriptor(uri!!, "w")
        } else {
            @Suppress("DEPRECATION") val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "UltraLiteRecorder")
            if (!dir.exists()) dir.mkdirs()
            oldFile = File(dir, name)
            pfd = ParcelFileDescriptor.open(oldFile!!, ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_WRITE_ONLY or ParcelFileDescriptor.MODE_TRUNCATE)
        }
    }

    private fun createBall() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        ball = TextView(this).apply {
            text = "● 00:00"; textSize = 12f; setTextColor(0xFFFFFFFF.toInt()); setPadding(dp(12), dp(10), dp(12), dp(10)); gravity = Gravity.CENTER; setBackgroundColor(0xEE1E293B.toInt()); elevation = dp(8).toFloat()
            setOnTouchListener(object : View.OnTouchListener {
                var downX = 0; var downY = 0; var startX = 0; var startY = 0; var moved = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val p = v.layoutParams as WindowManager.LayoutParams
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { downX = e.rawX.toInt(); downY = e.rawY.toInt(); startX = p.x; startY = p.y; moved = false; return true }
                        MotionEvent.ACTION_MOVE -> { val dx=e.rawX.toInt()-downX; val dy=e.rawY.toInt()-downY; if (abs(dx)>dp(5)||abs(dy)>dp(5)) moved=true; p.x=startX+dx; p.y=startY+dy; try { wm?.updateViewLayout(v,p) } catch (_:Exception){}; return true }
                        MotionEvent.ACTION_UP -> { if (!moved) { v.performClick(); toggleMenu() }; return true }
                    }
                    return false
                }
            })
        }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(140) }
        wm?.addView(ball, lp)
    }

    private fun toggleMenu() {
        if (menu != null) { removeMenu(); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(7), dp(7), dp(7), dp(7)); setBackgroundColor(0xF0212938.toInt()) }
        val pause = Button(this).apply { text = if (paused) "Resume" else "Pause"; isAllCaps = false; setOnClickListener { if (paused) { resumeRecording(); text = "Pause" } else { pauseRecording(); text = "Resume" } } }
        val stop = Button(this).apply { text = "Stop"; isAllCaps = false; setOnClickListener { stopRecording() } }
        box.addView(pause, LinearLayout.LayoutParams(dp(112), dp(46)))
        box.addView(stop, LinearLayout.LayoutParams(dp(112), dp(46)).apply { topMargin = dp(4) })
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(195) }
        menu = box
        try { wm?.addView(box, lp) } catch (_: Exception) { menu = null }
    }

    private fun pauseRecording() {
        if (!recording || paused) return
        try { recorder?.pause(); paused = true; pauseAt = SystemClock.elapsedRealtime(); updateTimer(); Toast.makeText(this, "Paused", Toast.LENGTH_SHORT).show() }
        catch (e: Exception) { Toast.makeText(this, "Pause failed: ${e.message}", Toast.LENGTH_SHORT).show() }
    }
    private fun resumeRecording() {
        if (!recording || !paused) return
        try { recorder?.resume(); pausedTotal += SystemClock.elapsedRealtime() - pauseAt; paused = false; updateTimer(); Toast.makeText(this, "Resumed", Toast.LENGTH_SHORT).show() }
        catch (e: Exception) { Toast.makeText(this, "Resume failed: ${e.message}", Toast.LENGTH_SHORT).show() }
    }
    private fun updateTimer() {
        val now = if (paused) pauseAt else SystemClock.elapsedRealtime()
        val sec = ((now - startedAt - pausedTotal).coerceAtLeast(0) / 1000).toInt()
        ball?.text = (if (paused) "Ⅱ " else "● ") + String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
    }
    private fun stopRecording() {
        if (!recording && recorder == null) { stopSelf(); return }
        recording = false; handler.removeCallbacks(ticker)
        try { recorder?.stop() } catch (_: Exception) {}
        releaseAll(true)
        Toast.makeText(this, "Saved in Movies/UltraLiteRecorder", Toast.LENGTH_LONG).show()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    private fun releaseAll(keepOutput: Boolean) {
        try { display?.release() } catch (_: Exception) {}; display = null
        try { recorder?.reset() } catch (_: Exception) {}; try { recorder?.release() } catch (_: Exception) {}; recorder = null
        try { projection?.stop() } catch (_: Exception) {}; projection = null
        try { pfd?.close() } catch (_: Exception) {}; pfd = null
        if (Build.VERSION.SDK_INT >= 29 && uri != null) {
            try { if (keepOutput) contentResolver.update(uri!!, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null) else contentResolver.delete(uri!!, null, null) } catch (_: Exception) {}
        } else if (!keepOutput) try { oldFile?.delete() } catch (_: Exception) {}
        uri = null; oldFile = null
        removeMenu(); try { ball?.let { wm?.removeView(it) } } catch (_: Exception) {}; ball = null
    }
    private fun removeMenu() { try { menu?.let { wm?.removeView(it) } } catch (_: Exception) {}; menu = null }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { handler.removeCallbacks(ticker); if (recording || recorder != null) releaseAll(false); super.onDestroy() }
}
