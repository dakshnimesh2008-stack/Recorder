package com.daksh.ultraliterecorder

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Typeface
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var overlayInfo: TextView
    private lateinit var start: Button
    private val captureRequest = 5107
    private val overlayRequest = 5108

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        makeUi()
    }

    private fun makeUi() {
        val bg = Color.rgb(13, 17, 25)
        val card = Color.rgb(25, 32, 45)
        val green = Color.rgb(100, 225, 164)
        val white = Color.rgb(244, 247, 252)
        val muted = Color.rgb(168, 181, 198)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(28), dp(22), dp(24)); setBackgroundColor(bg) }
        val scroll = ScrollView(this).apply { addView(root) }
        root.addView(TextView(this).apply { text = "●  ULTRALITE  /  PRO"; textSize = 12f; letterSpacing = .12f; setTextColor(green) })
        root.addView(TextView(this).apply { text = "Screen Recorder"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white); setPadding(0, dp(12), 0, dp(5)) })
        root.addView(TextView(this).apply { text = "Clean controls. Quick access while gaming."; textSize = 14f; setTextColor(muted) })
        val statusCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16)); setBackgroundColor(card) }
        root.addView(statusCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(26) })
        statusCard.addView(TextView(this).apply { text = "RECORDING STATUS"; textSize = 11f; letterSpacing = .1f; setTextColor(muted) })
        status = TextView(this).apply { text = "Ready to record"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white); setPadding(0, dp(8), 0, dp(5)) }
        statusCard.addView(status)
        overlayInfo = TextView(this).apply { text = overlayText(); textSize = 13f; setTextColor(muted) }
        statusCard.addView(overlayInfo)
        start = Button(this).apply { text = "START RECORDING"; isAllCaps = false; textSize = 14f; setTextColor(Color.rgb(5, 20, 12)); backgroundTintList = android.content.res.ColorStateList.valueOf(green); setOnClickListener { begin() } }
        root.addView(start, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(22) })
        root.addView(Button(this).apply { text = "Enable floating timer ball"; isAllCaps = false; setTextColor(white); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(49, 61, 79)); setOnClickListener { enableOverlay() } }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
        root.addView(TextView(this).apply {
            text = "HOW TO USE\n1. Enable the floating timer permission.\n2. Tap Start and allow screen capture.\n3. Tap the floating ball to open Pause/Resume and Stop.\n4. Videos are saved in Movies/UltraLiteRecorder.\n\nThis build records video only (no internal game audio). Android can still stop recording if you force-stop the app, reboot, or revoke capture permission. No app can bypass those system controls."
            textSize = 13f; setTextColor(muted); setLineSpacing(dp(5).toFloat(), 1f); setPadding(0, dp(24), 0, 0)
        })
        setContentView(scroll)
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) { enableOverlay(); return }
        start.isEnabled = false
        start.text = "WAITING FOR PERMISSION…"
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION") startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    private fun enableOverlay() {
        if (Settings.canDrawOverlays(this)) { overlayInfo.text = overlayText(); return }
        @Suppress("DEPRECATION") startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
    }

    @Deprecated("Android activity result compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest) {
            start.isEnabled = true; start.text = "START RECORDING"
            if (resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, RecordingService::class.java).apply { action = RecordingService.ACTION_START; putExtra(RecordingService.EXTRA_RESULT_CODE, resultCode); putExtra(RecordingService.EXTRA_DATA, data) }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                status.text = "Starting… check floating timer"
            } else status.text = "Screen capture cancelled"
        }
        overlayInfo.text = overlayText()
    }
    override fun onResume() { super.onResume(); if (::overlayInfo.isInitialized) overlayInfo.text = overlayText() }
    private fun overlayText() = if (Settings.canDrawOverlays(this)) "Floating timer ball: enabled" else "Floating timer ball: permission needed"
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
