# UltraLite Recorder Pro v2

Native Kotlin Android project.

### Features in this build
- Cleaner phone-friendly dark UI, with resolution (720p/540p/480p) and frame-rate (30/24/15 FPS) settings.
- Optional microphone audio or silent recording.
- Movable floating timer bubble with Pause/Resume/Stop controls.
- Foreground recording notification.
- Quick Settings tile service named “UltraLite Recorder”. Install the app, open Quick Settings edit mode, and drag the tile into active tiles.

### Build
Upload the **contents** of this ZIP to the root of a GitHub repository (do not upload the ZIP as the only project file). Commit, then run the included GitHub Actions workflow. Download the APK from Artifacts after a successful build.

### Important limitations
- Internal game/system audio and mixed internal+microphone audio are not implemented in this version. The audio setting currently offers silent video or microphone audio only.
- A floating overlay may be captured by some Android/device implementations; this needs on-device verification.
- Android does not let an app guarantee survival after Force stop, reboot, system revocation, or a crash.
- The Quick Settings tile must be manually added by the user in the system tile editor.
- This project has not been compiled or tested on the target phone in this environment.
